import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activities-description',
  templateUrl: './activities-description.component.html',
  styleUrls: ['./activities-description.component.css']
})
export class ActivitiesDescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
